import express from 'express';
import usersController from './controllers/users.js';
import databaseConnection from './utils/database.js';
import cors from 'cors'; 

const app = express();
app.use(express.json());


app.use(cors());

const port = 3000;

app.get("/", (request, response) => {
    response.status(200).send("Bem vindo à API de Usuários!");
});

app.use('/user', usersController);

databaseConnection().then(() => {
    app.listen(port, () => {
        console.log(`App running in http://localhost:${port}`);
    });
});

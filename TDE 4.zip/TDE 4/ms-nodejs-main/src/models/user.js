import mongoose from "mongoose";

const UserSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    idade: { type: Number, required: true },
    genero: { type: String, enum: ['Masculino', 'Feminino', 'Outro'], required: true },
    telefone: { type: String, required: true },
    cpf: { type: String, required: true, unique: true },
    rg: { type: String, required: true, unique: true }
});

// Criando o modelo de usuário
const User = mongoose.model('User', UserSchema);
export default User;
import mongoose from "mongoose";
const key = 'q47uDmtcst1fAGrU';
const URI = `mongodb+srv://bfroza:${key}@cluster0.w5sn6nr.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`

const databaseConnection = async () => {
    if (!global.mongoose) {
        mongoose.set("strictQuery", false)
        global.mongoose = await mongoose.connect(URI)
        .then(()=>console.log('connected to mongodb'))
        .catch(e=>console.log(e));
    }
}

export default databaseConnection
import { validarCPF } from '../js validate/cpf.js';
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('cadastroForm');

    form.addEventListener('submit', async (event) => {
        event.preventDefault(); 

        const cpfInput = document.getElementById('cpf');
        const cpf = cpfInput.value;
        const cpfValido = validarCPF(cpf);

        if (!cpfValido) {
            Swal.fire({
                title: 'CPF inválido',
                text: 'O CPF informado é inválido. Por favor, insira um CPF válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
            cpfInput.style.borderColor = 'red';
            cpfInput.focus(); 
            return; 
        }

        const formData = new FormData(form); 
        const params = Object.fromEntries(formData); 

        try {
            const response = await fetch('http://localhost:3000/user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(params) 
            });

            if (!response.ok) {
                throw new Error('Erro ao cadastrar usuário');
            }

            const data = await response.json();
            console.log(data); 
            window.location.href = '../html/index.html'
        } catch (error) {
            console.log(error);
        }
    });
});

export function validarEmail(inputId) {
    const input = document.getElementById(inputId);
    const email = input.value;
    const emailSpan = document.getElementById(inputId + "Span");

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(email)) {
        input.style.borderColor = 'green'; 
        return true; // Retorna true se o email for válido
    } else {
        input.style.borderColor = 'red'; 

        if (!email.includes("@")) {
            Swal.fire({
                title: 'Email inválido',
                text: 'O email está sem o @. Por favor, insira um email válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
        }
        if (!email.includes(".")) {
            Swal.fire({
                title: 'Email inválido',
                text: 'O email está sem o ".". Por favor, insira um email válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
        }
        return false; // Retorna false se o email for inválido
    }
}

window.onload = function() {
    const emailInput = document.getElementById('email');
    emailInput.addEventListener('blur', function() {
        validarEmail('email');
    });

    const form = document.getElementById('cadastroForm');
    // Adiciona um ouvinte de eventos ao evento 'submit'
    form.addEventListener('submit', function(event) {
        // Verifica se o email é válido antes de enviar o formulário
        const emailValido = validarEmail('email');

        // Impede o envio do formulário se o email não for válido
        if (!emailValido) {
            event.preventDefault();
        }

        // Remove o ouvinte de eventos após a validação
        form.removeEventListener('submit', arguments.callee);
    });
};

const inputRG = document.getElementById('rg');
inputRG.addEventListener('input', function(event) {
    const rgLimpo = this.value.replace(/\D/g, ''); // Remove tudo exceto os números
    let rgFormatado = '';
    if (rgLimpo.length <= 10) { // Limita o tamanho máximo para 11 caracteres (10 números + 1 hífen)
        rgFormatado = rgLimpo.replace(/^(\d{2})(\d{3})(\d{3})(\d{1})$/, '$1.$2.$3-$4'); // Formatação padrão de RG
    } else {
        rgFormatado = rgLimpo.slice(0, 11); // Limita o RG a 11 caracteres (caso o usuário tente digitar mais)
    }
    this.value = rgFormatado; // Define o valor do input como o RG formatado
});

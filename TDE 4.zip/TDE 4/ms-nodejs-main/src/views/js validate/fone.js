const inputTelefone = document.getElementById('telefone');
inputTelefone.addEventListener('input', function(event) {
    const numeroLimpo = this.value.replace(/\D/g, '');
    let numeroFormatado = '';
    if (numeroLimpo.length === 11) {
        numeroFormatado = numeroLimpo.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
    } else if (numeroLimpo.length === 10) {
        numeroFormatado = numeroLimpo.replace(/^(\d{2})(\d{4})(\d{4})$/, '($1) $2-$3');
    } else {
       
        numeroFormatado = numeroLimpo;
    }
    
   
    this.value = numeroFormatado;
});

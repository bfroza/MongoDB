export function validarEmail(inputId) {
    const input = document.getElementById(inputId);
    const email = input.value;
    const emailSpan = document.getElementById(inputId + "Span");

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(email)) {
        input.style.borderColor = 'green'; 
        return true; 
    } else {
        input.style.borderColor = 'red'; 

        if (!email.includes("@")) {
            Swal.fire({
                title: 'Email inválido',
                text: 'O email está sem o @. Por favor, insira um email válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
        }
        if (!email.includes(".")) {
            Swal.fire({
                title: 'Email inválido',
                text: 'O email está sem o ".". Por favor, insira um email válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
        }
        return false; 
    }
}

window.onload = function() {
    const emailInput = document.getElementById('email');
    emailInput.addEventListener('blur', function() {
        validarEmail('email');
    });

    const form = document.getElementById('cadastroForm');
    form.addEventListener('submit', function(event) {
        const emailValido = validarEmail('email');

        
        if (!emailValido) {
            event.preventDefault();
        }
    });
};

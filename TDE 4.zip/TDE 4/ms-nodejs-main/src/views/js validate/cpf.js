function mascaraCpf() {
    const inputCPF = document.getElementById('cpf');
    const cpfSpan = document.getElementById("cpfSpan");

    inputCPF.addEventListener('input', function(event) {
        let cpfLimpo = this.value.replace(/\D/g, '');
        cpfLimpo = cpfLimpo.slice(0, 11);
        let cpfFormatado = '';
        for (let i = 0; i < cpfLimpo.length; i++) {
            if (i === 3 || i === 6) {
                cpfFormatado += '.';
            } else if (i === 9) {
                cpfFormatado += '-';
            }
            cpfFormatado += cpfLimpo.charAt(i);
        }
        this.value = cpfFormatado;
    });

    inputCPF.addEventListener('blur', function(event) {
        const cpf = this.value;
        const cpfFormatado = validarCPF(cpf);

        if (!cpfFormatado) {
            Swal.fire({
                title: 'CPF inválido',
                text: 'O CPF informado é inválido. Por favor, insira um CPF válido.',
                icon: 'error',
                confirmButtonColor: '#d33'
            });
           
        } else {
            
        }
    });

    const form = document.getElementById('cadastroForm');
    form.addEventListener('submit', function(event) {
        const cpf = inputCPF.value;
        const cpfValido = validarCPF(cpf);
        
        if (!cpfValido) {
            event.preventDefault(); 
            form.removeEventListener('submit', arguments.callee);
        }
    });
}

export function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g,'');	
    if(cpf == '') return false;	
    if (cpf.length != 11 || 
        cpf == "00000000000" || 
        cpf == "11111111111" || 
        cpf == "22222222222" || 
        cpf == "33333333333" || 
        cpf == "44444444444" || 
        cpf == "55555555555" || 
        cpf == "66666666666" || 
        cpf == "77777777777" || 
        cpf == "88888888888" || 
        cpf == "99999999999") {
            return false;
        }
    let add = 0;	
    for (let i = 0; i < 9; i ++)		
        add += parseInt(cpf.charAt(i)) * (10 - i);	
    let rev = 11 - (add % 11);	
    if (rev == 10 || rev == 11)		
        rev = 0;	
    if (rev != parseInt(cpf.charAt(9)))		
        return false;		
    add = 0;	
    for (let i = 0; i < 10; i ++)		
        add += parseInt(cpf.charAt(i)) * (11 - i);	
    rev = 11 - (add % 11);	
    if (rev == 10 || rev == 11)	
        rev = 0;	
    if (rev != parseInt(cpf.charAt(10)))
        return false;

    return true;
}

mascaraCpf();

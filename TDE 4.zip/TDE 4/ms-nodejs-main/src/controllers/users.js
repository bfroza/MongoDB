import { Router } from 'express';
import { getUsers,createUser, deleteUser, updateUser,getUsersByName,deleteUserByName } from '../services/users.js';
import User from '../models/user.js'; // Corrigindo a importação do modelo de usuário

const router = Router();



router.get("/", async (request, response) => {
    const { nome } = request.query;
    let users;

    if (nome) {
        // Se o parâmetro 'nome' estiver presente na query, busca os usuários cujos nomes contenham a parte fornecida
        const usersWithName = await getUsersByName(nome);
        users = usersWithName ? usersWithName : []; // Coloca os usuários encontrados em um array ou um array vazio se nenhum encontrado
    } else {
        // Caso contrário, retorna todos os usuários
        users = await getUsers();
    }

    return response.status(200).send(users);
});

router.post("/", async (request, response) => {
    const params = {
        nome: request.body.nome,
        email: request.body.email,
        idade: request.body.idade,
        genero: request.body.genero,
        telefone: request.body.telefone,
        cpf: request.body.cpf,
        rg: request.body.rg,
    };
    const user = await createUser(params); // Usar a função para criar um novo usuário
    return response.status(201).send(user);
});

router.delete("/:id", async (request, response) => {
    await deleteUser(request.params.id); // Usar a função para excluir um usuário
    return response.status(204).send();
});

router.put("/:id", async (request, response) => {
    const user = await updateUser(request.params.id, { // Usar a função para atualizar um usuário pelo ID
        nome: request.body.nome,
        email: request.body.email,
        idade: request.body.idade,
        genero: request.body.genero,
        telefone: request.body.telefone,
        cpf: request.body.cpf,
        rg: request.body.rg,
    });
    return response.status(200).send(user);
});

router.delete("/", async (request, response) => {
    const { nome } = request.query;
    if (!nome) {
        return response.status(400).send("O parâmetro 'nome' é obrigatório."); // Retorna um erro se o parâmetro 'nome' estiver ausente
    }
    await deleteUserByName(nome); // Chama a função para excluir o usuário pelo nome
    return response.status(204).send(); // Retorna uma resposta de sucesso sem conteúdo
});


export default router;

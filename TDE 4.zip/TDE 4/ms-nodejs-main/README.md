# Desenvolvimento de uma API NodeJS com Banco MongoDB

## Exemplo de código utilizado em Aula

## Libs utilizadas
- Express
- Typescript
- Mongo DB
- Mongoose


## Instalar dependencias

```
yarn install
``` 

## Executando o projeto 

```
yarn start
``` 


import { Router } from 'express';
import { getUsers, getUser, createUser, deleteUser, updateUser,deleteUserByName } from '../services/users.js';
import User from '../models/user.js'; // Corrigindo a importação do modelo de usuário

const router = Router();

router.get("/", async (request, response) => {
    const users = await getUsers();
    return response.status(200).send(users);
});

router.post("/", async (request, response) => {
    const params = {
        nome: request.body.nome,
        email: request.body.email,
        idade: request.body.idade,
        genero: request.body.genero,
        telefone: request.body.telefone,
        cpf: request.body.cpf,
        rg: request.body.rg,
    };
    const user = await createUser(params); // Usar a função para criar um novo usuário
    return response.status(201).send(user);
});

router.delete("/:id", async (request, response) => {
    await deleteUser(request.params.id); // Usar a função para excluir um usuário
    return response.status(204).send();
});

router.delete("/", async (request, response) => {
    const { nome } = request.query;
    if (!nome) {
        return response.status(400).send("O parâmetro 'nome' é obrigatório."); // Retorna um erro se o parâmetro 'nome' estiver ausente
    }
    await deleteUserByName(nome); // Chama a função para excluir o usuário pelo nome
    return response.status(204).send(); // Retorna uma resposta de sucesso sem conteúdo
});

router.put("/:id", async (request, response) => {
    const user = await updateUser(request.params.id, { // Usar a função para atualizar um usuário pelo ID
        nome: request.body.nome,
        email: request.body.email,
        idade: request.body.idade,
        genero: request.body.genero,
        telefone: request.body.telefone,
        cpf: request.body.cpf,
        rg: request.body.rg,
    });
    return response.status(200).send(user);
});

export default router;



import User from '../models/user.js'

export const getUsers = async () => {
    const users = await User.find();
    return users;
};

export const getUser = async (id) => {
    const user = await User.findById(id);
    return user;
};

export const createUser = async (params) => {
    const user = new User(params);
    await user.save();
    return user;
};

export const deleteUser = async (id) => {
    await User.findByIdAndDelete(id);
};

export const deleteUserByName = async (nome) => {
    await User.deleteMany({ nome: nome }); // Exclui todos os usuários com o nome especificado
};

export const updateUser = async (id, params) => {
    const user = await User.findByIdAndUpdate(id, params, { new: true });
    return user;
};
export function validarEmail(email) {
    

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(email)) {
    
        return true; 
    } else {
  

        if (!email.includes("@")) {
           return false
        }
        if (!email.includes(".")) {
         return false
        }
        return false; 
    }
}


import { validarCPF } from '../ms-nodejs-main/test-cpf';
import { validarEmail } from '../ms-nodejs-main/test-email';

describe('teste unitario para funcao validateCPF',() =>{
    it('Teste com CPF valido',() => {
        var cpf = '027.623.040-08';
        expect(validarCPF(cpf)).toBe(true);
 })
 it('Teste com CPF invalido', () => {
    var cpf = '111.111.111-11';
    expect(validarCPF(cpf)).toBe(false);
})
});

describe('teste unitario para funcao validateEMAIL',() =>{
    it('Teste com Email valido',() => {
        var email = '032758@aluno.uricer.edu';
        expect(validarEmail(email)).toBe(true);
 })
 it('Teste com Email invalido', () => {
    var email = 'bruno.calica';
    expect(validarEmail(email)).toBe(false);
})
});